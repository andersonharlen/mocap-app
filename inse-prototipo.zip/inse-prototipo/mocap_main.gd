extends Node2D

var face_landmarker
var esta_gravando = false
var frames_da_animacao = []

# Puxando os botões que você já criou na tela
@onready var label_status = $VBoxContainer/Label
@onready var btn_gravar = $VBoxContainer/BtnGravar

func _ready():
	# Testa se o plugin do MediaPipe foi reconhecido pelo Godot
	if ClassDB.class_exists("FaceLandmarkerOptions"):
		label_status.text = "Plugin GDMP Carregado! IA Pronta."
		print("Sucesso: MediaPipe encontrado!")
	else:
		label_status.text = "Erro: O Plugin ainda não foi carregado."
		print("Falha: Verifique os Plugins nas configurações.")

func _process(_delta):
	# Deixamos o processamento vazio neste exato momento só para
	# limpar os erros vermelhos e focar em ver se o plugin ativou.
	pass

func _on_btn_gravar_pressed():
	esta_gravando = !esta_gravando
	if esta_gravando:
		btn_gravar.text = "Parar Gravação"
	else:
		btn_gravar.text = "Iniciar Captura"

func _on_btn_salvar_pressed():
	if frames_da_animacao.is_empty():
		label_status.text = "Nenhum frame para salvar ainda."
		return
		
	var caminho = "user://animacao_mocap.json"
	var arquivo = FileAccess.open(caminho, FileAccess.WRITE)
	arquivo.store_string(JSON.stringify(frames_da_animacao, "\t"))
	arquivo.close()
	label_status.text = "JSON Salvo com sucesso!"
